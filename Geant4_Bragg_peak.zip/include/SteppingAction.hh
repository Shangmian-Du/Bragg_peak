#ifndef B1SteppingAction_h
#define B1SteppingAction_h 1

#include "G4UserSteppingAction.hh"
#include "globals.hh"
#include "G4ThreeVector.hh"
#include "CLHEP/Units/SystemOfUnits.h"

class G4LogicalVolume;

namespace B1
{

class EventAction;

/// Stepping action class

class SteppingAction : public G4UserSteppingAction
{
  public:
    SteppingAction(EventAction* eventAction);
    ~SteppingAction() override = default;  // 使用=default

    // method from the base class
    virtual void UserSteppingAction(const G4Step*);
    
    // WriteNeuInfo 函数定义在类内
    void WriteNeuInfo(const std::string& particleName,
                          G4double energyDeposit,
                          const G4ThreeVector& position,
                          G4double stepLength,
                          G4int trackID,
                          G4int eventID);
  private:
    EventAction* fEventAction = nullptr;
    G4LogicalVolume* fScoringVolume = nullptr;
};

}

#endif