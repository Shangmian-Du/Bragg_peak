#ifndef PHYSICSLIST_HH
#define PHYSICSLIST_HH

#include "G4VModularPhysicsList.hh"
#include "G4EmStandardPhysics.hh" // 电磁物理
#include "G4HadronPhysicsQGSP_BERT_HP.hh" // 强相互作用物理

class PhysicsList : public G4VModularPhysicsList {
public:
    PhysicsList();
    ~PhysicsList();

    void ConstructParticle() override;
    void ConstructProcess() override;
};

#endif // PHYSICSLIST_HH
