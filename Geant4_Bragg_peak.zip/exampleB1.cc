#include "G4RunManagerFactory.hh"
#include "G4SteppingVerbose.hh"
#include "G4UImanager.hh"
#include "QBBC.hh"

#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "ActionInitialization.hh"
#include "DetectorConstruction.hh"
#include "EventAction.hh"
#include "PhysicsList.hh"
#include "PrimaryGeneratorAction.hh"
#include "RunAction.hh"
#include "SteppingAction.hh"
#include "Randomize.hh"
#include <fstream>

using namespace B1;

int main(int argc, char** argv)
{
    G4int precision = 4;
    G4SteppingVerbose::UseBestUnit(precision);

    // 创建多线程模式的 RunManager
    auto* runManager = G4RunManagerFactory::CreateRunManager(G4RunManagerType::MT);

    // 设置使用的线程数量为 16
    runManager->SetNumberOfThreads(20);

    G4int numParticles = 10000;

    // 用户初始化 - 探测器构造
    runManager->SetUserInitialization(new DetectorConstruction());

    // 用户初始化 - 物理过程列表
    G4VModularPhysicsList* physicsList = new QBBC;
    physicsList->SetVerboseLevel(1);
    runManager->SetUserInitialization(physicsList);

    // 用户初始化 - 动作初始化
    runManager->SetUserInitialization(new ActionInitialization());

    // 初始化 Geant4 内核
    runManager->Initialize(); // 确保在调用 BeamOn 之前初始化

    // 处理命令行参数
    if (argc > 1) {
        numParticles = std::stoi(argv[1]); // 从命令行设置粒子数
    }
    // 开始模拟
    runManager->BeamOn(numParticles);

    // 释放资源
    delete runManager;
    return 0;
}
