#include "SteppingAction.hh"
#include "EventAction.hh"
#include "DetectorConstruction.hh"

#include "G4Step.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"
#include "PhysicsList.hh"
#include "G4Track.hh"
#include "G4ParticleDefinition.hh"
#include "G4ThreeVector.hh"
#include <fstream>
#include <iomanip> // 用于设置输出格式
#include <string>
#include "CLHEP/Units/SystemOfUnits.h"

namespace B1
{

SteppingAction::SteppingAction(EventAction* eventAction)
: fEventAction(eventAction)
{}

void SteppingAction::WriteNeuInfo(const std::string& particleName,
                                  G4double energyDeposit,
                                  const G4ThreeVector& position,
                                  G4double stepLength,
                                  G4int trackID,
                                  G4int eventID) {  // 添加 trackID 参数
    std::ofstream outputFile;
    outputFile.open("particle_info.txt", std::ios::app);  // 以追加模式打开文件
    outputFile << "EventID: " << eventID << ", "  // 输出事件编号
               << "TrackID: " << trackID << ", "  // 输出粒子的轨迹编号
               << "Particle: " << particleName << ", "  // 输出粒子名称
               << "Energy Deposit: " << energyDeposit  << " MeV, "  // 能量沉积转为MeV
               << "Position: (" << position.x()  << " mm, "
               << position.y() << " mm, " << position.z()  << " mm), "
               << "Step Length: " << stepLength  << " mm\n";  // 步长转为mm
    outputFile.close();
}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    if (!fScoringVolume) {
        const auto detConstruction = static_cast<const DetectorConstruction*>(
            G4RunManager::GetRunManager()->GetUserDetectorConstruction());
        fScoringVolume = detConstruction->GetScoringVolume();
    }

    // get volume of the current step
    G4LogicalVolume* volume
        = step->GetPreStepPoint()->GetTouchableHandle()
          ->GetVolume()->GetLogicalVolume();

    // check if we are in scoring volume
    if (volume != fScoringVolume) return;

    // collect energy deposited in this step
    G4double edepStep = step->GetTotalEnergyDeposit();
    fEventAction->AddEdep(edepStep);

    // 获取粒子轨迹
    const G4Track* track = step->GetTrack();

    // 获取粒子能量沉积
    G4double energyDeposit = step->GetTotalEnergyDeposit();

    // 获取粒子的位置
    G4ThreeVector position = step->GetPostStepPoint()->GetPosition();

    // 获取粒子的路径长度（步长）
    G4double stepLength = step->GetStepLength();

    // 获取粒子类型
    G4ParticleDefinition* particleDef = track->GetDefinition();
    G4String particleName = particleDef->GetParticleName();

    //获取粒子的轨迹编号
    G4int trackID = track->GetTrackID();

    //获取事件号    
    G4int eventID = G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID();
    // 使用 WriteNeuInfo 输出粒子信息
    WriteNeuInfo(particleName, energyDeposit, position, stepLength, trackID, eventID);
}

}