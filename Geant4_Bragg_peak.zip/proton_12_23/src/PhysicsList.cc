#include "PhysicsList.hh"
#include "G4Gamma.hh"
#include "G4Neutron.hh"
#include "G4Electron.hh"
#include "G4Proton.hh"

#include "G4EmStandardPhysics.hh"
#include "G4HadronPhysicsQGSP_BERT_HP.hh"

// Constructor
PhysicsList::PhysicsList()
    : G4VModularPhysicsList() {
    SetVerboseLevel(1); // 设置输出详细级别

    // 注册电磁物理过程
    RegisterPhysics(new G4EmStandardPhysics());
    // 注册高精度中子物理过程
    RegisterPhysics(new G4HadronPhysicsQGSP_BERT_HP());
}

// Destructor
PhysicsList::~PhysicsList() {}

// Define particles
void PhysicsList::ConstructParticle() {
    // 定义伽马粒子
    G4Gamma::GammaDefinition();
    // 定义中子粒子
    G4Neutron::NeutronDefinition();
    // 定义电子
    G4Electron::ElectronDefinition();
    // 定义质子
    G4Proton::ProtonDefinition();
}

// Define processes
void PhysicsList::ConstructProcess() {
    AddTransportation(); // 添加粒子运输过程
    G4VModularPhysicsList::ConstructProcess(); // 注册模块化物理列表的所有进程
    G4EmStandardPhysics *emPhysics = new G4EmStandardPhysics();
    emPhysics->ConstructProcess();
}
